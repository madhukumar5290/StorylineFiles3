// LRS Connection
let scormReporting = false;
let xAPIReporting = false;
let kerRef = "";
let secretRef = "";
let endPointRef = "";

//Reporting Variables
let objectID = "https://www.learningdojo.net/xapi/course1";
let objectName = "Video 1";

// Display labels
let videoPath = 'media/main.m4v';
let title = 'Example Title';
let description = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.";
let copyrightText = '&#169; 2020 Learning Dojo';
let profilePic = 'media/me.jpg';